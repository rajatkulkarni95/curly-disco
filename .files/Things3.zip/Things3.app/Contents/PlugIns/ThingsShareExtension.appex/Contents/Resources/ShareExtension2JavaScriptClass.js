var ShareExtension2JavaScriptClass = function() {};

ShareExtension2JavaScriptClass.prototype = {
    run: function(arguments) {

        // Pass the baseURI of the webpage to the extension.
        var selectedText = '' + window.getSelection();

        arguments.completionFunction({
                                     "baseURI": document.baseURI,
                                     "href": location.href,
                                     "URL": document.URL,
                                     "selectedText": selectedText,
                                     "pageTitle": document.title
                                     });
    },
};

// The JavaScript file must contain a global object named "ExtensionPreprocessingJS".
var ExtensionPreprocessingJS = new ShareExtension2JavaScriptClass;
